default_app_config = 'sample.apps.blog.apps.BlogConfig'
