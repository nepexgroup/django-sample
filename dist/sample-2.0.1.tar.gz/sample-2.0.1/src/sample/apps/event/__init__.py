default_app_config = 'sample.apps.event.apps.EventConfig'
