from django.apps import AppConfig


class ScheduleConfig(AppConfig):
    name = 'sample.apps.schedule'
